// const fs = require('fs');
let id = 0;

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function strcmp(a, b) {
    if (a.toString() < b.toString()) return 0;
    if (a.toString() > b.toString()) return 0;
    return 1;
}

const checkForm = () => {
    let result = '';
    let isNormal = true;
    let deliveryMethod;
    let name = document.getElementById("inlineFormInputGroupName").value;
    let secondName = document.getElementById("inlineFormInputGroupSecondName").value;
    let paymentMethod = document.getElementById("inlineFormSelectPref").value;
    let mobilePhone = document.getElementById("inlineFormInputGroupNumber").value;
    let homeAddress = document.getElementById("inlineFormInputGroupAddress").value;
    let dayOfDelivery = document.getElementById("deliveryDay").value;
    let ready = document.getElementById("inlineFormCheck").value;

    var temp = document.getElementsByName('gridRadios');
    for (let i = 0; i < temp.length; i++) {
        if (temp[i].checked)
            deliveryMethod = temp[i].value;
    }
    if (!(name.match(/^[a-zA-Z ]+$/)) || !name) {
        result = result + 'Nieprawidłowe imię.\n';
        isNormal = false;
    }
    if (!(secondName.match(/^[a-zA-Z ]+$/)) || !secondName) {
        result = result + 'Nieprawidłowe nazwisko.\n';
        isNormal = false;
    }
    if (paymentMethod === "Sposób oplaty") {
        result = result + 'Nieprawidłowa metoda płatności.\n';
        isNormal = false;
    } else {
        if (paymentMethod === '1') paymentMethod = "MasterCard";
        if (paymentMethod === '2') paymentMethod = "Visa";
        if (paymentMethod === '3') paymentMethod = "Przelew bankowy";
        if (paymentMethod === '4') paymentMethod = "Gotówka";
    }
    if (!(mobilePhone.match(/^(?:(?:(?:(?:\+|00)\d{2})?[ -]?(?:(?:\(0?\d{2}\))|(?:0?\d{2})))?[ -]?(?:\d{3}[- ]?\d{2}[- ]?\d{2}|\d{2}[- ]?\d{2}[- ]?\d{3}|\d{7})|(?:(?:(?:\+|00)\d{2})?[ -]?\d{3}[ -]?\d{3}[ -]?\d{3}))$/))) {
        result = result + 'Nieprawidłowy telefon komórkowy.\n';
        isNormal = false;
    }
    if (!(homeAddress.match(/[A-Za-z0-9'\.\-\s\,]/)) || !homeAddress) {
        result = result + 'Nieprawidłowy adres dostawy.\n';
        isNormal = false;
    }
    if (!dayOfDelivery) {
        result = result + 'Nieprawidłowy dzień dostawy.\n';
        isNormal = false;
    } else {
        if (dayOfDelivery === '1') dayOfDelivery = "Dostawa na dzisiaj";
        if (dayOfDelivery === '2') dayOfDelivery = "Dostawa na jutro";
        if (dayOfDelivery === '3') dayOfDelivery = "Inny termin";
    }

    if (deliveryMethod === 'sklep') {
        deliveryMethod = 'Dostawa od naszego sklepu';
    }
    if (deliveryMethod === 'czlowiek') {
        deliveryMethod = 'Dostawa z użyciem transportu państwa';
    }
    if (deliveryMethod === 'inne') {
        deliveryMethod = 'Inne';
    }

    if (!isNormal) {
        result = result + 'Sprobuj ponownie.';
        alert(result);
    } else {
        const order = {
            'name': name,
            'secondName': secondName,
            'paymentMethod': paymentMethod,
            'mobilePhone': mobilePhone,
            'homeAddress': homeAddress,
            'dayOfDelivery': dayOfDelivery,
            'deliveryMethod': deliveryMethod
        }
        addLocalStorage(order);
    }
    result = '';
    window.location.href = 'zamowienie.html';
}

const addLocalStorage = (order) => {
    id = Object.keys(localStorage).length;
    while (window.localStorage.getItem(id)) {
        id++;
    }
    // alert(id);
    window.localStorage.setItem(id.toString(), JSON.stringify(order));
    // saveToTheFile(order);

}

const generateLastOrders = () => {
    let max_id = 0;
    for (let i = 0; i < 100; i++) {
        if (window.localStorage.getItem(i)) {
            max_id = i;
        }
    }
    document.getElementById('orders').innerHTML = '';
    console.log(window.localStorage.length);
    for (let i = 0; i <= max_id; i++) {
        if (window.localStorage.getItem(i)) {
            let item = JSON.parse(window.localStorage.getItem(i.toString()));
            let parsedItem = Object.values(item);
            console.log(parsedItem);
            document.getElementById('orders').innerHTML += '<div class="zamowienie"> Dzien dostawy: ' + parsedItem[5] +
                '.<br> Sposób dostawy: ' + parsedItem[6] + '.<br> Numer: ' + (i + 1) +
                '. <br> <button id="delete" onclick="deleteFromStorage(' + i + ')">Delete</button></div><br>';
        }
    }
}

const checkLogin = () => {
    let name = document.getElementById("inlineFormInputLogin").value;
    let pass = document.getElementById("inlineFormInputLogin").value;
    if (name.toString() === 'admin' && pass.toString() === 'admin') {
        window.location.href = 'adminpanel.html';
    } else {
        alert("Nieprawidłowe dane!");
    }
}

const generateAdminPanel = () => {
    let keys;
    document.getElementById("orders").innerHTML = '';
    fetch('https://lomatt.github.io/zamowienia.json')
        .then((response) => {
            return response.json();
        })
        .then ((data) => {
            console.log(data.length);
            keys = Object.keys(data);
            console.log(keys);
            for (let i = 0; i < data.length; i++) {
                console.log(data[keys[i]].data);
                document.getElementById("orders").innerHTML = document.getElementById("orders").innerHTML + '<div class="order' + i + '"> Dzien dostawy: ' +
                    capitalizeFirstLetter(data[keys[i]].data.dayOfDelivery.toString()) + '.<br> Delivery method: ' + capitalizeFirstLetter(data[keys[i]].data.deliveryMethod.toString()) +
                '.<br> Home Address: ' + capitalizeFirstLetter(data[keys[i]].data.homeAddress.toString()) + '.<br> Mobile Phone: ' + data[keys[i]].data.mobilePhone +
                '.<br> Name: ' + capitalizeFirstLetter(data[keys[i]].data.name.toString()) + '.<br> Payment method: ' + capitalizeFirstLetter(data[keys[i]].data.paymentMethod.toString()) +
                '.<br> Second name: ' + capitalizeFirstLetter(data[keys[i]].data.secondName.toString()) + '.<br></div><br><br>';
            }
        });



}

const deleteFromStorage = (i) => {
    window.localStorage.removeItem(i);
    console.log('Deleting item with id ' + i);
    window.location.href = 'ostatniezamowienia.html';
}